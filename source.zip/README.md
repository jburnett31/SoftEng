MotionDetect contains an example motion detection algorithm.
compilation:
<pre>
$ cmake .
$ make
$ ./MotionDetect
</pre>
press q to quit

This shows the absolute difference between a set of three consecutive images.
Measures this difference every 700ms and takes a screenshot.


